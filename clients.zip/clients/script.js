// Variables globales
let clientsData = [];
let currentEditingCell = null;
let progressChart = null;

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser le graphique de progression
    initProgressChart();
    
    // Charger les données depuis localStorage
    loadFromLocalStorage();
    
    // Initialiser les écouteurs d'événements
    initEventListeners();
});

// Initialisation du graphique de progression
function initProgressChart() {
    const ctx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Fait', 'Non fait'],
            datasets: [{
                data: [0, 100],
                backgroundColor: ['#28a745', '#e9ecef'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true
                }
            }
        }
    });
}

// Initialisation des écouteurs d'événements
function initEventListeners() {
    // Bouton pour ajouter un client
    document.getElementById('addClientBtn').addEventListener('click', openAddClientModal);
    
    // Bouton pour sauvegarder un client
    document.getElementById('saveClientBtn').addEventListener('click', saveClient);
    
    // Boutons d'importation/exportation
    document.getElementById('importExcelBtn').addEventListener('click', () => document.getElementById('excelFileInput').click());
    document.getElementById('excelFileInput').addEventListener('change', importExcel);
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);
    document.getElementById('exportPdfBtn').addEventListener('click', exportToPdf);
    
    // Filtres
    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('regionFilter').addEventListener('change', applyFilters);
    document.getElementById('dateFilter').addEventListener('input', applyFilters);
    
    // Gestion des clics sur le tableau pour l'édition inline
    document.getElementById('clientsTable').addEventListener('click', handleTableClick);
    
    // Gestion des clics en dehors d'une cellule en édition
    document.addEventListener('click', function(e) {
        if (currentEditingCell && !currentEditingCell.contains(e.target) && e.target.tagName !== 'INPUT' && e.target.tagName !== 'SELECT') {
            finishCellEditing();
        }
    });
}

// Charger les données depuis localStorage
function loadFromLocalStorage() {
    const savedData = localStorage.getItem('clientsData');
    if (savedData) {
        clientsData = JSON.parse(savedData);
        renderTable();
        updateProgressChart();
        updateRegionFilter();
    }
}

// Sauvegarder les données dans localStorage
function saveToLocalStorage() {
    localStorage.setItem('clientsData', JSON.stringify(clientsData));
}

// Ouvrir le modal pour ajouter un client
function openAddClientModal() {
    document.getElementById('modalTitle').textContent = 'Ajouter un Client';
    document.getElementById('clientForm').reset();
    const modal = new bootstrap.Modal(document.getElementById('clientModal'));
    modal.show();
}

// Sauvegarder un client
function saveClient() {
    const formData = {
        raisonSociale: document.getElementById('raisonSociale').value,
        site: document.getElementById('site').value,
        region: document.getElementById('region').value,
        localisation: document.getElementById('localisation').value,
        sumExt: document.getElementById('sumExt').value,
        fait: document.getElementById('fait').value,
        motif: document.getElementById('motif').value,
        numeroF1V: document.getElementById('numeroF1V').value,
        dateVisite: document.getElementById('dateVisite').value,
        gps: document.getElementById('gps').value,
        id: Date.now().toString() // Identifiant unique
    };
    
    clientsData.push(formData);
    saveToLocalStorage();
    renderTable();
    updateProgressChart();
    updateRegionFilter();
    
    // Fermer le modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('clientModal'));
    modal.hide();
}

// Rendu du tableau
function renderTable() {
    const tbody = document.querySelector('#clientsTable tbody');
    tbody.innerHTML = '';
    
    clientsData.forEach(client => {
        const tr = document.createElement('tr');
        
        // Créer les cellules pour chaque colonne
        const columns = [
            { field: 'raisonSociale', editable: true },
            { field: 'site', editable: true },
            { field: 'region', editable: true },
            { field: 'localisation', editable: true },
            { field: 'sumExt', editable: true },
            { field: 'fait', editable: true, type: 'select', options: ['', 'Oui', 'Non'] },
            { field: 'motif', editable: true },
            { field: 'numeroF1V', editable: true },
            { field: 'dateVisite', editable: true, type: 'date' },
            { field: 'gps', editable: true, type: 'gps' }
        ];
        
        columns.forEach(column => {
            const td = document.createElement('td');
            
            if (column.editable) {
                td.classList.add('editable');
                td.dataset.field = column.field;
                td.dataset.id = client.id;
                
                if (column.type === 'select') {
                    td.dataset.type = 'select';
                    td.dataset.options = JSON.stringify(column.options);
                } else if (column.type === 'date') {
                    td.dataset.type = 'date';
                } else if (column.type === 'gps') {
                    td.dataset.type = 'gps';
                    if (client[column.field]) {
                        const gpsLink = document.createElement('a');
                        gpsLink.href = `https://www.google.com/maps?q=${client[column.field]}`;
                        gpsLink.target = '_blank';
                        gpsLink.className = 'gps-link';
                        gpsLink.innerHTML = `<i class="fas fa-map-marker-alt"></i> ${client[column.field]}`;
                        td.appendChild(gpsLink);
                    } else {
                        td.textContent = '';
                    }
                } else {
                    td.textContent = client[column.field] || '';
                }
            } else {
                td.textContent = client[column.field] || '';
            }
            
            tr.appendChild(td);
        });
        
        // Ajouter les boutons d'action
        const actionsTd = document.createElement('td');
        actionsTd.className = 'action-buttons';
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn btn-sm btn-danger action-btn';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.addEventListener('click', () => deleteClient(client.id));
        
        actionsTd.appendChild(deleteBtn);
        tr.appendChild(actionsTd);
        
        tbody.appendChild(tr);
    });
}

// Gestion des clics sur le tableau
function handleTableClick(e) {
    const cell = e.target.closest('td');
    if (!cell || !cell.classList.contains('editable')) return;
    
    // Si on clique sur un lien GPS, ne pas activer l'édition
    if (e.target.closest('.gps-link')) return;
    
    startCellEditing(cell);
}

// Commencer l'édition d'une cellule
function startCellEditing(cell) {
    // Si une autre cellule est en cours d'édition, terminer son édition
    if (currentEditingCell) {
        finishCellEditing();
    }
    
    currentEditingCell = cell;
    const field = cell.dataset.field;
    const id = cell.dataset.id;
    const client = clientsData.find(c => c.id === id);
    const currentValue = client[field] || '';
    
    // Vider la cellule
    cell.innerHTML = '';
    
    // Créer l'élément d'édition approprié
    let editElement;
    
    if (cell.dataset.type === 'select') {
        editElement = document.createElement('select');
        editElement.className = 'form-select cell-edit-input';
        
        const options = JSON.parse(cell.dataset.options);
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option;
            optionElement.textContent = option;
            if (option === currentValue) {
                optionElement.selected = true;
            }
            editElement.appendChild(optionElement);
        });
    } else if (cell.dataset.type === 'date') {
        editElement = document.createElement('input');
        editElement.type = 'date';
        editElement.className = 'form-control cell-edit-input';
        editElement.value = currentValue;
    } else {
        editElement = document.createElement('input');
        editElement.type = 'text';
        editElement.className = 'form-control cell-edit-input';
        editElement.value = currentValue;
    }
    
    // Ajouter l'élément à la cellule
    cell.appendChild(editElement);
    editElement.focus();
    
    // Ajouter les écouteurs d'événements
    editElement.addEventListener('blur', () => {
        setTimeout(() => {
            // Délai pour permettre aux autres gestionnaires de s'exécuter d'abord
            if (currentEditingCell === cell) {
                finishCellEditing();
            }
        }, 100);
    });
    
    editElement.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            finishCellEditing();
        } else if (e.key === 'Escape') {
            currentEditingCell = null;
            renderTable();
        }
    });
}

// Terminer l'édition d'une cellule
function finishCellEditing() {
    if (!currentEditingCell) return;
    
    const field = currentEditingCell.dataset.field;
    const id = currentEditingCell.dataset.id;
    const client = clientsData.find(c => c.id === id);
    
    // Récupérer la valeur de l'élément d'édition
    const editElement = currentEditingCell.querySelector('input, select');
    if (editElement) {
        const newValue = editElement.value;
        
        // Mettre à jour les données
        client[field] = newValue;
        saveToLocalStorage();
        
        // Mettre à jour le graphique si le champ "fait" a été modifié
        if (field === 'fait') {
            updateProgressChart();
        }
    }
    
    currentEditingCell = null;
    renderTable();
}

// Supprimer un client
function deleteClient(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce client ?')) {
        clientsData = clientsData.filter(client => client.id !== id);
        saveToLocalStorage();
        renderTable();
        updateProgressChart();
        updateRegionFilter();
    }
}

// Mettre à jour le graphique de progression
function updateProgressChart() {
    const totalClients = clientsData.length;
    const completedClients = clientsData.filter(client => client.fait === 'Oui').length;
    const completionPercentage = totalClients > 0 ? Math.round((completedClients / totalClients) * 100) : 0;
    
    // Mettre à jour la barre de progression
    const progressBar = document.getElementById('progressBar');
    progressBar.style.width = `${completionPercentage}%`;
    progressBar.textContent = `${completionPercentage}%`;
    progressBar.setAttribute('aria-valuenow', completionPercentage);
    
    // Mettre à jour le graphique circulaire
    progressChart.data.datasets[0].data = [completedClients, totalClients - completedClients];
    progressChart.update();
}

// Mettre à jour le filtre de région
function updateRegionFilter() {
    const regionFilter = document.getElementById('regionFilter');
    const currentValue = regionFilter.value;
    
    // Effacer les options existantes sauf la première
    while (regionFilter.options.length > 1) {
        regionFilter.remove(1);
    }
    
    // Obtenir les régions uniques
    const regions = [...new Set(clientsData.map(client => client.region).filter(Boolean))];
    
    // Ajouter les nouvelles options
    regions.forEach(region => {
        const option = document.createElement('option');
        option.value = region;
        option.textContent = region;
        regionFilter.appendChild(option);
    });
    
    // Restaurer la valeur sélectionnée si elle existe toujours
    if (regions.includes(currentValue)) {
        regionFilter.value = currentValue;
    }
}

// Appliquer les filtres
function applyFilters() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const regionFilter = document.getElementById('regionFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;
    
    const rows = document.querySelectorAll('#clientsTable tbody tr');
    
    rows.forEach(row => {
        const client = clientsData.find(c => c.id === row.querySelector('td[data-id]').dataset.id);
        
        let visible = true;
        
        // Filtre de recherche
        if (searchTerm) {
            const searchableFields = ['raisonSociale', 'site', 'region', 'localisation', 'motif'];
            const matchesSearch = searchableFields.some(field => 
                client[field] && client[field].toLowerCase().includes(searchTerm)
            );
            if (!matchesSearch) visible = false;
        }
        
        // Filtre de région
        if (regionFilter && client.region !== regionFilter) {
            visible = false;
        }
        
        // Filtre de date
        if (dateFilter && client.dateVisite !== dateFilter) {
            visible = false;
        }
        
        row.style.display = visible ? '' : 'none';
    });
}

// Importer depuis Excel
function importExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        
        // Supposer que les données sont dans la première feuille
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convertir en JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        
        // Mapper les données au format attendu
        const mappedData = jsonData.map(row => ({
            raisonSociale: row['RAISON_SOCIALE'] || '',
            site: row['SITE'] || '',
            region: row['RÉGION'] || '',
            localisation: row['LOCALISATION'] || '',
            sumExt: row['∑ EXT'] || '',
            fait: row['FAIT'] || '',
            motif: row['MOTIF'] || '',
            numeroF1V: row['N° F 1V'] || '',
            dateVisite: row['DATE DE VISITE'] ? formatExcelDate(row['DATE DE VISITE']) : '',
            gps: row['GPS'] || '',
            id: Date.now().toString() + Math.random().toString(36).substr(2, 5) // ID unique
        }));
        
        // Ajouter les nouvelles données
        clientsData = [...clientsData, ...mappedData];
        saveToLocalStorage();
        renderTable();
        updateProgressChart();
        updateRegionFilter();
        
        // Réinitialiser l'input file
        e.target.value = '';
    };
    reader.readAsArrayBuffer(file);
}

// Formater une date Excel au format YYYY-MM-DD
function formatExcelDate(excelDate) {
    // Si c'est déjà une chaîne au format date, la retourner
    if (typeof excelDate === 'string') {
        // Essayer de convertir différents formats de date
        const dateParts = excelDate.split(/[\/.-]/);
        if (dateParts.length === 3) {
            // Supposer que le format est JJ/MM/AAAA ou MM/JJ/AAAA
            let day, month, year;
            
            // Essayer de déterminer le format
            if (parseInt(dateParts[0]) > 12) {
                // Format JJ/MM/AAAA
                day = dateParts[0];
                month = dateParts[1];
            } else if (parseInt(dateParts[1]) > 12) {
                // Format MM/JJ/AAAA
                day = dateParts[1];
                month = dateParts[0];
            } else {
                // Par défaut, supposer JJ/MM/AAAA
                day = dateParts[0];
                month = dateParts[1];
            }
            
            year = dateParts[2];
            if (year.length === 2) {
                year = '20' + year; // Supposer 20xx pour les années à 2 chiffres
            }
            
            return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }
        return excelDate;
    }
    
    // Si c'est un nombre (date Excel), convertir en date JavaScript
    if (typeof excelDate === 'number') {
        const date = new Date((excelDate - 25569) * 86400 * 1000);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    return '';
}

// Exporter vers Excel
function exportToExcel() {
    // Créer un nouveau classeur
    const wb = XLSX.utils.book_new();
    
    // Préparer les données pour l'export
    const exportData = clientsData.map(client => ({
        'RAISON_SOCIALE': client.raisonSociale || '',
        'SITE': client.site || '',
        'RÉGION': client.region || '',
        'LOCALISATION': client.localisation || '',
        '∑ EXT': client.sumExt || '',
        'FAIT': client.fait || '',
        'MOTIF': client.motif || '',
        'N° F 1V': client.numeroF1V || '',
        'DATE DE VISITE': client.dateVisite || '',
        'GPS': client.gps || ''
    }));
    
    // Créer une feuille de calcul
    const ws = XLSX.utils.json_to_sheet(exportData);
    
    // Ajouter la feuille au classeur
    XLSX.utils.book_append_sheet(wb, ws, "Clients");
    
    // Générer le fichier Excel et le télécharger
    XLSX.writeFile(wb, "clients_export.xlsx");
}

// Exporter vers PDF
function exportToPdf() {
    // Configurer jsPDF
    const doc = new jsPDF('l', 'mm', 'a4');
    
    // Configurer autoTable
    const tableColumn = [
        'RAISON_SOCIALE', 'SITE', 'RÉGION', 'LOCALISATION', '∑ EXT', 
        'FAIT', 'MOTIF', 'N° F 1V', 'DATE DE VISITE', 'GPS'
    ];
    
    // Préparer les données pour l'export
    const tableRows = clientsData.map(client => [
        client.raisonSociale || '',
        client.site || '',
        client.region || '',
        client.localisation || '',
        client.sumExt || '',
        client.fait || '',
        client.motif || '',
        client.numeroF1V || '',
        client.dateVisite || '',
        client.gps || ''
    ]);
    
    // Générer le tableau dans le PDF
    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 20,
        theme: 'grid',
        styles: {
            fontSize: 8,
            cellPadding: 2,
            overflow: 'linebreak'
        },
        columnStyles: {
            0: { cellWidth: 30 }, // RAISON_SOCIALE
            1: { cellWidth: 25 }, // SITE
            2: { cellWidth: 20 }, // RÉGION
            3: { cellWidth: 25 }, // LOCALISATION
            4: { cellWidth: 15 }, // ∑ EXT
            5: { cellWidth: 15 }, // FAIT
            6: { cellWidth: 25 }, // MOTIF
            7: { cellWidth: 15 }, // N° F 1V
            8: { cellWidth: 20 }, // DATE DE VISITE
            9: { cellWidth: 25 }  // GPS
        },
        headStyles: {
            fillColor: [66, 139, 202],
            textColor: 255,
            fontStyle: 'bold'
        }
    });
    
    // Ajouter un titre
    doc.setFontSize(16);
    doc.text("Liste des Clients et Sites", 14, 15);
    
    // Ajouter la date d'exportation
    const today = new Date();
    const dateStr = today.toLocaleDateString('fr-FR');
    doc.setFontSize(10);
    doc.text(`Exporté le: ${dateStr}`, 250, 15);
    
    // Télécharger le PDF
    doc.save("clients_export.pdf");
}

// Fonction pour initialiser les données de démonstration (optionnel)
function initDemoData() {
    if (clientsData.length === 0) {
        clientsData = [
            {
                id: '1',
                raisonSociale: 'Entreprise ABC',
                site: 'Site Principal',
                region: 'Nord',
                localisation: 'Paris',
                sumExt: '5',
                fait: 'Oui',
                motif: 'Maintenance annuelle',
                numeroF1V: 'F1V-001',
                dateVisite: '2023-06-15',
                gps: '48.8566,2.3522'
            },
            {
                id: '2',
                raisonSociale: 'Société XYZ',
                site: 'Usine 2',
                region: 'Sud',
                localisation: 'Marseille',
                sumExt: '3',
                fait: 'Non',
                motif: 'En attente',
                numeroF1V: 'F1V-002',
                dateVisite: '2023-07-20',
                gps: '43.2965,5.3698'
            },
            {
                id: '3',
                raisonSociale: 'Groupe DEF',
                site: 'Bureau Commercial',
                region: 'Est',
                localisation: 'Lyon',
                sumExt: '2',
                fait: 'Oui',
                motif: 'Inspection technique',
                numeroF1V: 'F1V-003',
                dateVisite: '2023-05-10',
                gps: '45.7640,4.8357'
            }
        ];
        saveToLocalStorage();
        renderTable();
        updateProgressChart();
        updateRegionFilter();
    }
}

// Appeler initDemoData() dans l'initialisation si vous souhaitez des données de démonstration
// document.addEventListener('DOMContentLoaded', function() {
//     // ... autres initialisations ...
//     initDemoData();
// });